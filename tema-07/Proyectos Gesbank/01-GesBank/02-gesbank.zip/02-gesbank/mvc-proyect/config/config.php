<?php
# Configuración básica aplicación MVC

# Ruta absoluta
define('URL', 'http://localhost/dwes/DesarrolloWebEntornoServidor/tema-07/proyectos/GesBank/02-gesbank/mvc-proyect/');

# Constante de la Base de Datos
define('HOST', 'localhost');
define('DB', 'gesbank');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');


?>