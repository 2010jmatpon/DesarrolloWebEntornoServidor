<?php

    /*

        Controlador: index.php
        Descripción: Carga el  formulario de  datos  para  la conversión

    */

    # Model
    # No hay modelo

    # Vista
    include "views/viewResultado.php";

?>