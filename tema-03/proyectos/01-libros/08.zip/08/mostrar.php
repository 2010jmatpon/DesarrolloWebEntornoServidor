<?php
#Libreria
include 'libs/crud_funciones.php';
#Model
include "models/model.mostrar.php";

#Vista
include "views/view.mostrar.php";
?>