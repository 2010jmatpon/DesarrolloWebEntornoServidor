<?php
#Libreria
include 'libs/crud_funciones.php';
#Model
include "models/model.update.php";

#Vista
include "views/view.index.php";
?>