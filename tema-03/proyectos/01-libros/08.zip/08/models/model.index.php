<?php
/*
Modelo: model.index.php
Descripcion: Genera los datos de los libros
*/

$libros = generar_tabla();



?>