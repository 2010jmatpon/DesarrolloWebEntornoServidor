<?php
#Libreria
include 'libs/crud_funciones.php';
#Model
// include "models/model.index.php";
// include "models/model.nuevo.php";

#Vista
include "views/view.nuevo.php";
?>