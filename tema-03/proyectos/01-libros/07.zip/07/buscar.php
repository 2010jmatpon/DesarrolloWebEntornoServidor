<?php
include "models/model.index.php";
include "models/model.buscar.php";

include "views/view.index.php";
?>