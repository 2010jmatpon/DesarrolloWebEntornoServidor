<?php
include "models/model.index.php";
include "views/view.index.php";
?>