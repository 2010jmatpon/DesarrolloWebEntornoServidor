<?php
#Libreria
include 'libs/crud_funciones.php';
#Model
require "models/model.mostrar.php";

#Vista
require "views/view.mostrar.php";
?>