<?php
    $categorias = generar_tabla_categorias();
?>