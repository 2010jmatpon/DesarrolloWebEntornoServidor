<header class="pb-3 mb-44 border-bottom">
    <i class="bi bi bi-boombox-fill" style="font-size: 3rem; color: cornflowerblue;"></i>
    <span class="fs-4">Proyecto 3.2 CRUD Artículos</span>
</header>