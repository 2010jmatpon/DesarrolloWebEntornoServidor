<?php

   include 'models/model.mostrar.php'; 
   include 'views/view.mostrar.php'; 


?>