<?php
    include 'models/model.nuevo.php';
    include 'views/view.nuevo.php';

?>