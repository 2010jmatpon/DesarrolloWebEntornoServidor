<?php

    /*
        fichero: model.index.php
        Descripción: modelo del proceso index.php

    */

    $pais = getPaises();
    $genero = getGeneros();
    $peliculas = getPeliculas();
    
    
?>