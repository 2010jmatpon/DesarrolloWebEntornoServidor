<?php

    /*
        fichero: model.nuevo.php
        Descripción: modelo del proceso nuevo.php. 

    */

   
    $pais = getPaises();
    $genero = getGeneros();
    $peliculas = getPeliculas();
    
?>