<?php

    /*

        Modelo: model.mostrar.PHP

        - Carga los datos
        - Recibo por GET indice de la película que se desea mostrar

    */

    $pais = getPaises();
    $genero = getGeneros();
    $peliculas = getPeliculas();
    

?>