<?php

    /*

        model.create.PHP

        - Añade un elemento a la tabla 

    */

    $pais = getPaises();
    $genero = getGeneros();
    $peliculas = getPeliculas();

?>