<header class="pb-3 mb-4 border-bottom">
    <i class="bi bi-people-fill" style="font-size: 3rem; color: cornflowerblue;"></i>
    <span class="fs-4">Proyecto 4.3 CRUD Alumnos</span>
</header>