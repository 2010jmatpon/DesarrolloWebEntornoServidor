<?php 


    include "class/class.alumno.php";
    include "class/class.arrayAlumno.php";

    include "models/model.mostrar.php";

    include "views/view.mostrar.php";

?>