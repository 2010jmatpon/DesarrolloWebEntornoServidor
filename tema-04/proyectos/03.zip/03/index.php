<?php 
    /*
        Controlador index.php
        Muestra los detalles de lso articulos
    */

    #clases
    include("class/class.alumno.php");
    include("class/class.arrayAlumno.php");

    #model
    include("models/model.index.php");

    #views
    include("views/view.index.php");

?>