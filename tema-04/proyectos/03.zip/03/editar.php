<?php 

    # Librería
    include 'class/class.alumno.php';
    include 'class/class.arrayAlumno.php';
    
    # Model
    include 'models/model.editar.php';

    # View
    include 'views/view.editar.php';

?>