<?php 

    // Cargamos libreria 
    include "class/class.alumno.php";
    include "class/class.arrayAlumno.php";

    // Cargamos el modelo
    include "models/model.update.php";

    // Cargamos la vista 
    include "views/view.index.php";

?>