<?php 

    # Librería
    include 'class/class.articulo.php';
    include 'class/class.arrayArticulo.php';
    
    # Model
    include 'models/model.editar.php';

    # View
    include 'views/view.editar.php';

?>