<?php 


    include "class/class.articulo.php";
    include "class/class.arrayArticulo.php";

    include "models/model.mostrar.php";

    include "views/view.mostrar.php";

?>