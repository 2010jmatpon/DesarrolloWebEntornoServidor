<?php

    /*

        Controlador: nuevo.php
        Descripción: mostrar un formulario que permita añadir nuevo libro
    */

    # Class
    include 'class/class.arrayArticulo.php';
    include 'class/class.articulo.php';

    # Model
    include 'models/model.nuevo.php';

    # Vista
    include 'views/view.nuevo.php';

?>