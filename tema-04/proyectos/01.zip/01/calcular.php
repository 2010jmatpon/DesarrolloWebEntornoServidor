<?php

    /*
        index.php

        Controlador principal
    */

    #Clase calculadora
    include("class/class.calculadora.php");

    # Cargo el modelo
    include("models/model.calcular.php");
    
    # Cargo la vista
    include("views/view.resultado.php");


?>