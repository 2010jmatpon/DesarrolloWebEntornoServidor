<?php

    include "class/class.arrayJugadores.php";
    include "class/class.jugador.php";

    include "models/model.index.php";

    include "views/view.index.php";

?>