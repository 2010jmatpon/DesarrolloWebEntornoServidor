<?php
    #modelo
    include "models/hexadecimal.php";

    #vista
    include "views/viewResultado.php";
?>