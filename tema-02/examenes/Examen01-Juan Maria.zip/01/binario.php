<?php
    #modelo
    include "models/binario.php";

    #vista
    include "views/viewResultado.php";
?>