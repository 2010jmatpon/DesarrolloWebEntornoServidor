<?php
    #modelo
    include "models/conversor.php";

    #vista
    include "views/viewConversor.php";
?>