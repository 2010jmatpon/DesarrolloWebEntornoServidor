<?php
    #modelo
    include "models/octal.php";

    #vista
    include "views/viewResultado.php";
?>