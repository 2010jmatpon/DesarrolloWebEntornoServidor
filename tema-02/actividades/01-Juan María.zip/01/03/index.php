<?php
$var = "String y ";
$var2 = "Concatenar";
$res = $var . $var2;
echo $res;
?>