<?php
    include "models/calcular.php";
    include "views/resultado.php";
?>